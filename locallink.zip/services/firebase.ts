import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

// ------------------------------------------------------------------
// CONFIGURATION
// Replace the values below with your Firebase Project Configuration
// Found in: Firebase Console -> Project Settings -> General
// ------------------------------------------------------------------

// Access env safely by casting import.meta to any to satisfy TypeScript
const env = (import.meta as any).env;

const firebaseConfig = {
  // Try to read from environment variables first (if set in Netlify), 
  // otherwise fallback to placeholder strings.
  apiKey: env?.VITE_FIREBASE_API_KEY || "YOUR_API_KEY_HERE",
  authDomain: env?.VITE_FIREBASE_AUTH_DOMAIN || "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: env?.VITE_FIREBASE_PROJECT_ID || "YOUR_PROJECT_ID",
  storageBucket: env?.VITE_FIREBASE_STORAGE_BUCKET || "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: env?.VITE_FIREBASE_MESSAGING_SENDER_ID || "YOUR_MESSAGING_SENDER_ID",
  appId: env?.VITE_FIREBASE_APP_ID || "YOUR_APP_ID"
};

let app;
let db;
let auth;

try {
  // Simple check to ensure we don't try to init with placeholders
  if (firebaseConfig.apiKey && firebaseConfig.apiKey !== "YOUR_API_KEY_HERE") {
    app = initializeApp(firebaseConfig);
    db = getFirestore(app);
    auth = getAuth(app);
    console.log("Firebase initialized successfully");
  } else {
    console.log("Firebase config not found or invalid. Running in Local Mode (Offline).");
  }
} catch (error) {
  console.error("Error initializing Firebase:", error);
}

export { db, auth };